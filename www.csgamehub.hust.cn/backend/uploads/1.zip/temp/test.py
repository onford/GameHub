def p2p(N,F,us,d,ui):
	return max(F/us,F/d,N*F/(us+N*ui))
def cs(N,F,us,d):
	return max(N*F/us,F/d)

k = 1000
F = 20. * k * k
us = 30. * k
di = 2. * k
n = [10.,100.,1000.]
u = [300.,700.,2. * k]

print("P2P:")
for nn in n:
	for uu in u:
		print(p2p(nn,F,us,di,uu))

print("CS:")
for nn in n:
	for uu in u:
		print(cs(nn,F,us,di))
