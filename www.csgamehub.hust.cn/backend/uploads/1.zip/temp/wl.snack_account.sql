create view snack_account(`date`,amount,`type`,`comment`) as
(select `date`,amount,'积蓄',`comment` from wl.snack_income union 
select `date`,-expense,'支出',concat(`comment`,'。') from wl.snack_outcome join wl.daily_account on (wl.snack_outcome.daily_account_id = wl.daily_account.id)
union select 'TOTAL',SUM(`amount`) + 3 * (datediff(curdate(),'2024-06-16') + 1),'积蓄','' from ( (select id,amount from wl.snack_income union select -wl.daily_account.id,-expense from wl.snack_outcome join wl.daily_account on (wl.snack_outcome.daily_account_id = wl.daily_account.id))) as `account`(id,amount)
union select curdate(),3 * (datediff(curdate(),'2024-06-16') + 1),'积蓄','从开始日\'2024-06-16\'起每日积蓄3元的总和。')
order by `date`;